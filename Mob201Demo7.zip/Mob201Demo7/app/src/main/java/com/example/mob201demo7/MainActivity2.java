package com.example.mob201demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ////
        ImageView imageView = findViewById(R.id.imageView2);
        ImageView gioImg = findViewById(R.id.imageView3Gio);
        ImageView phutImg = findViewById(R.id.imageView4Phut);
        ImageView giayImg = findViewById(R.id.imageView5Giay);

        Animation aniGio = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.gio);
        Animation aniPhut = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.phut);
        Animation aniGiay = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.giay);
        gioImg.startAnimation(aniGio);
        phutImg.startAnimation(aniPhut);
        giayImg.startAnimation(aniGiay);
    }
}