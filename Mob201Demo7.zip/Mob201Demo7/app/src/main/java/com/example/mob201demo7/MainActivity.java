package com.example.mob201demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        zoom();
    }
    public void blink()
    {
        ImageView imageView = findViewById(R.id.imageView);
        Animation animation
                = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.blink);
        imageView.startAnimation(animation);
    }
    public void clock()
    {
        ImageView imageView = findViewById(R.id.imageView);
        Animation animation
                = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.clock);
        imageView.startAnimation(animation);
    }
    public void fade()
    {
        ImageView imageView = findViewById(R.id.imageView);
        Animation animation
                = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.fade);
        imageView.startAnimation(animation);
    }
    public void move()
    {
        ImageView imageView = findViewById(R.id.imageView);
        Animation animation
                = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.move);
        imageView.startAnimation(animation);
    }
    public void zoom()
    {
        ImageView imageView = findViewById(R.id.imageView);
        Animation animation
                = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.zoom);
        imageView.startAnimation(animation);
    }

}