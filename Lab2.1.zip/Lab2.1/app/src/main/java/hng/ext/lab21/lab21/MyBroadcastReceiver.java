package hng.ext.lab21.lab21;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by hungnq on 9/15/17.
 */

public class MyBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String intentMessage = intent.getExtras().getString("bm");
        Toast.makeText(context,intentMessage,Toast.LENGTH_LONG).show();
    }
}
