package hng.ext.lab21.lab21;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button btnBroadcast;
    EditText txtName,txtClass;

    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //gan

        btnBroadcast = (Button)findViewById(R.id.btnBroad);
        txtName = (EditText)findViewById(R.id.editName);
        txtClass = (EditText)findViewById(R.id.editClass);

        //su kien
        btnBroadcast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                intent = new Intent(MainActivity.this,MyBroadcastReceiver.class);

                String str = "BM: Xin chao " + txtName.getText().toString()+" Lop: "+ txtClass.getText().toString();

                intent.putExtra("bm",str);

                sendBroadcast(intent);

            }
        });
    }
}
