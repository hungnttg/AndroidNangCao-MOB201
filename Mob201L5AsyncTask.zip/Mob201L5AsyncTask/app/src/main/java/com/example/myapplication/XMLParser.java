package com.example.myapplication;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class XMLParser {//thu vien boc tach XML
    public Document getDocmument(String xml) throws IOException, SAXException
    {
        Document document=null;//khai bao tai lieu
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();//tao object
        DocumentBuilder builder = null;//khai bao builder
        try {
            builder = factory.newDocumentBuilder();//dua tai lieu vao builder
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        InputSource inputSource = new InputSource();//dua input vao
        inputSource.setCharacterStream(new StringReader(xml));//tao luong
        inputSource.setEncoding("UTF-8");//utf8
        document = builder.parse(inputSource);//chuyen doi
        return document;
    }
    public final String getTextNodeValue(Node node)//lay be text cua node
    {
        Node child;
        if(node!=null)
        {
            for(child=node.getFirstChild();child!=null;child=child.getNextSibling())
            {
                if(child.getNodeType()==Node.TEXT_NODE)
                {
                    return child.getNodeValue();
                }
            }
        }
        return "";
    }
    public String getValue(Element item,String name)//lay ve gia tri
    {
        NodeList nodeList = item.getElementsByTagName(name);
        String txt = this.getTextNodeValue(nodeList.item(0));
        return  txt;
    }
}
