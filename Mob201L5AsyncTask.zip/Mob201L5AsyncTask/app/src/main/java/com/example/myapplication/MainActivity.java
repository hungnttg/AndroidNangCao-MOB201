package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    List<String> arrLs = new ArrayList<>();
    List<String> arrLk = new ArrayList<>();
    ArrayAdapter<String> adapter;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.lv);
        //goi ham lay du lieu tu server (goi ham doInBackground bang execute
        AsyncTask<String,Void,String> kq=
                new DaTienTrinh().execute("https://ngoisao.net/rss/hau-truong.rss");
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,arrLs);
        listView.setAdapter(adapter);


        intent = new Intent(this,MainActivity2.class);
        //su kien click vao item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String lk = arrLk.get(position);//lay ve vi tri
                intent.putExtra("linkweb",lk);
                startActivity(intent);
            }
        });
        //goi ham tra ve ket qua (onPostExecute)

    }
    public class DaTienTrinh extends AsyncTask<String,Void,String>
    {
        //thuc hien lay du lieu phia server
        @Override
        protected String doInBackground(String... strings) {
            StringBuilder builder = new StringBuilder();
            try {
                URL url = new URL(strings[0]);//lay ve link can doc
                //tao luong doc
                InputStreamReader reader
                        =new InputStreamReader(url.openConnection().getInputStream());
                //tao bo dem du lieu
                BufferedReader bufferedReader = new BufferedReader(reader);
                String dong="";
                while ((dong=bufferedReader.readLine())!=null)//chi doc khi dong khac null
                {
                    builder.append(dong);//dua du lieu vao builder
                }
                bufferedReader.close();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return builder.toString();
        }
        //day du lieu ve client
        @Override
        protected void onPostExecute(String s) {//doc tu chuoi s-> arrLs, arrLk
            super.onPostExecute(s);
            XMLParser xmlParser = new XMLParser();
            try {
                Document document = xmlParser.getDocmument(s);//tao tai lieu
                NodeList nodeList = document.getElementsByTagName("item");//lay ve cac node
                String title="";
                for(int i=0;i<nodeList.getLength();i++)
                {
                    Element element = (Element)nodeList.item(i);
                    title = xmlParser.getValue(element,"title")+"\n";
                    arrLs.add(title);
                    arrLk.add(xmlParser.getValue(element,"link"));
                }
                adapter.notifyDataSetChanged();
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}