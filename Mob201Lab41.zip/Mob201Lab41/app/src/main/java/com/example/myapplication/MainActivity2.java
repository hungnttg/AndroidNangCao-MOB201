package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView txtWF;
    ConnectivityManager connectivityManager;//quan ly ket noi
    NetworkInfo w,g;//thong tin mang
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txtWF = findViewById(R.id.txtWifi);

        connectivityManager = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);//su dung dich vu HDH
        w = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);//thong tin wifi
        g = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);//thong tin 4g
        if(w.isAvailable()==true){
            txtWF.setText("Dang dung Wifi");
        }
        else if (g.isAvailable()==true)
        {
            txtWF.setText("Dang dung 4G");
        }

    }
}