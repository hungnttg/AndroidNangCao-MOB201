package io.dp.media.player;

public class Const {
  public static final String TAG = "MyMediaPlayer";
}
